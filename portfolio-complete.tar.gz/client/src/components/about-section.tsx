import { Card, CardContent } from "@/components/ui/card";

interface UserData {
  about: {
    subtitle: string;
  };
  mission: string;
}

interface Value {
  title: string;
  subtitle: string;
  letter: string;
}

interface Education {
  degree: string;
  institution: string;
  period: string;
  cgpa?: string;
  percentage?: string;
}

interface AboutSectionProps {
  user: UserData;
  values: Value[];
  education: Education[];
}

export default function AboutSection({ user, values, education }: AboutSectionProps) {
  const getGradientColor = (index: number) => {
    const gradients = [
      "from-blue-400 to-purple-400",
      "from-purple-400 to-pink-400",
      "from-green-400 to-blue-400",
      "from-orange-400 to-red-400"
    ];
    return gradients[index % gradients.length];
  };

  const getEducationIcon = (degree: string) => {
    if (degree.includes("B.Tech")) return "🎓";
    if (degree.includes("12th") || degree.includes("Intermediate")) return "🏫";
    if (degree.includes("10th") || degree.includes("SSC")) return "📚";
    return "🎓";
  };

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            About <span className="text-purple-600">Me</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            {user.about.subtitle}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Mission */}
          <div className="space-y-8">
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
                  <span className="text-white text-xl">🎯</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">My Mission</h3>
              </div>
              <p className="text-gray-700 leading-relaxed">
                {user.mission}
              </p>
            </div>

            {/* Core Values */}
            <Card className="shadow-lg border border-gray-100">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Core Values</h3>
                <div className="grid grid-cols-2 gap-6">
                  {values.map((value, index) => (
                    <div key={value.title} className="text-center">
                      <div className={`w-16 h-16 bg-gradient-to-br ${getGradientColor(index)} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                        <span className="text-white font-bold text-lg">{value.letter}</span>
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-2">{value.title}</h4>
                      <p className="text-sm text-gray-600">{value.subtitle}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Educational Journey */}
          <div className="space-y-8">
            <Card className="shadow-lg border border-gray-100">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-8">Educational Journey</h3>
                <div className="space-y-6">
                  {education.map((edu, index) => (
                    <div key={index} className={`relative pl-8 ${index < education.length - 1 ? 'border-l-2 border-purple-200' : ''}`}>
                      <div className="absolute -left-3 top-2 w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs">{getEducationIcon(edu.degree)}</span>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-semibold text-gray-900">{edu.degree}</h4>
                        <p className="text-purple-600 font-medium">{edu.institution}</p>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-500">{edu.period}</span>
                          <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                            {edu.cgpa || edu.percentage}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
