import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface SkillCategory {
  programmingLanguages: string[];
  dataAnalysisLibraries: string[];
  databaseTools: string[];
  specializations: string[];
  proficiencyLevels: {
    name: string;
    category: string;
    level: number;
    color: string;
  }[];
}

interface SkillsSectionProps {
  skills: SkillCategory;
}

export default function SkillsSection({ skills }: SkillsSectionProps) {
  const skillCategories = [
    {
      title: "Programming Languages",
      icon: "💻",
      color: "bg-blue-500",
      skills: skills.programmingLanguages,
      iconColors: ["text-blue-600", "text-gray-600", "text-blue-600", "text-orange-600"]
    },
    {
      title: "Data Analysis Libraries",
      icon: "📊",
      color: "bg-purple-500",
      skills: skills.dataAnalysisLibraries,
      iconColors: ["text-purple-600", "text-blue-600", "text-green-600", "text-indigo-600"]
    },
    {
      title: "Database & Tools",
      icon: "🗄️",
      color: "bg-green-500",
      skills: skills.databaseTools,
      iconColors: ["text-orange-600", "text-blue-600", "text-gray-600", "text-green-600"]
    },
    {
      title: "Specializations",
      icon: "⚙️",
      color: "bg-orange-500",
      skills: skills.specializations,
      iconColors: ["text-purple-600", "text-red-600", "text-blue-600"]
    }
  ];

  return (
    <section id="skills" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Technical <span className="text-purple-600">Skills</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            A comprehensive toolkit for data analysis, software development, and problem-solving
          </p>
        </div>

        {/* Skills Grid - 4 columns */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {skillCategories.map((category, categoryIndex) => (
            <Card key={category.title} className="shadow-lg border border-gray-100 card-hover">
              <CardContent className="p-6">
                <div className={`w-12 h-12 ${category.color} rounded-xl flex items-center justify-center mb-4`}>
                  <span className="text-white text-xl">{category.icon}</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{category.title}</h3>
                <div className="space-y-3">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skill} className="flex items-center gap-3">
                      <div className={`w-8 h-8 ${category.iconColors[skillIndex] ? 'bg-gray-100' : 'bg-blue-100'} rounded-lg flex items-center justify-center`}>
                        <span className={`text-xs font-bold ${category.iconColors[skillIndex] || 'text-blue-600'}`}>
                          {skill.slice(0, 2)}
                        </span>
                      </div>
                      <span className="text-gray-700">{skill}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Proficiency Levels */}
        <Card className="shadow-lg border border-gray-100">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">Proficiency Levels</h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                {skills.proficiencyLevels.slice(0, 3).map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-gray-900">{skill.name}</span>
                      <span className="text-sm text-gray-600">{skill.category}</span>
                      <span className="text-sm font-semibold text-purple-600">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`bg-gradient-to-r ${skill.color} h-2 rounded-full transition-all duration-1000 ease-out`}
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="space-y-6">
                {skills.proficiencyLevels.slice(3).map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-gray-900">{skill.name}</span>
                      <span className="text-sm text-gray-600">{skill.category}</span>
                      <span className="text-sm font-semibold text-purple-600">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`bg-gradient-to-r ${skill.color} h-2 rounded-full transition-all duration-1000 ease-out`}
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
