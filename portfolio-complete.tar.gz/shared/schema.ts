import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const portfolios = pgTable("portfolios", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(),
  data: jsonb("data").notNull(),
});

export const contacts = pgTable("contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

// Portfolio data schema
export const portfolioDataSchema = z.object({
  user: z.object({
    name: z.string(),
    fullName: z.string(),
    tagline: z.string(),
    profileImage: z.string(),
    email: z.string(),
    phone: z.string(),
    location: z.string(),
    about: z.object({
      subtitle: z.string(),
    }),
    mission: z.string(),
    contactIntro: z.string(),
    stats: z.object({
      cgpa: z.string(),
      internships: z.string(),
      technologies: z.string(),
    }),
  }),
  values: z.array(z.object({
    title: z.string(),
    subtitle: z.string(),
    letter: z.string(),
  })),
  education: z.array(z.object({
    degree: z.string(),
    institution: z.string(),
    period: z.string(),
    cgpa: z.string().optional(),
    percentage: z.string().optional(),
  })),
  skills: z.object({
    programmingLanguages: z.array(z.string()),
    dataAnalysisLibraries: z.array(z.string()),
    databaseTools: z.array(z.string()),
    specializations: z.array(z.string()),
    proficiencyLevels: z.array(z.object({
      name: z.string(),
      category: z.string(),
      level: z.number(),
      color: z.string(),
    })),
  }),
  experiences: z.array(z.object({
    title: z.string(),
    company: z.string(),
    duration: z.string(),
    status: z.string(),
    highlight: z.string(),
    projectTitle: z.string(),
    type: z.string(),
    responsibilities: z.array(z.string()),
    technologies: z.array(z.string()),
    icon: z.string(),
    color: z.string(),
  })),
  featuredProject: z.object({
    title: z.string(),
    category: z.string(),
    description: z.string(),
    technologies: z.array(z.string()),
    achievements: z.array(z.object({
      value: z.string(),
      label: z.string(),
      icon: z.string(),
    })),
    features: z.array(z.object({
      name: z.string(),
      desc: z.string(),
    })),
  }),
  otherProjects: z.array(z.object({
    title: z.string(),
    description: z.string(),
    status: z.string(),
    technologies: z.array(z.string()),
    type: z.string(),
  })),
});

export const insertPortfolioSchema = createInsertSchema(portfolios).omit({
  id: true,
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
});

export type InsertPortfolio = z.infer<typeof insertPortfolioSchema>;
export type Portfolio = typeof portfolios.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;
export type PortfolioData = z.infer<typeof portfolioDataSchema>;
