import { Button } from "@/components/ui/button";

interface UserData {
  name: string;
  fullName: string;
  tagline: string;
  profileImage: string;
  stats: {
    cgpa: string;
    internships: string;
    technologies: string;
  };
}

interface HeroSectionProps {
  data: UserData;
}

export default function HeroSection({ data }: HeroSectionProps) {
  const handleDownloadResume = () => {
    window.open("/api/resume/download", "_blank");
  };

  const scrollToProjects = () => {
    document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="home" className="gradient-bg min-h-screen flex items-center relative overflow-hidden pt-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-white space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Hello, I'm<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                  {data.fullName.split(" ").slice(0, -1).join(" ")}<br />
                  {data.fullName.split(" ").slice(-1)}
                </span>
              </h1>
              <p className="text-xl text-gray-200 max-w-2xl">
                {data.tagline}
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={scrollToProjects}
                className="bg-white text-gray-900 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex items-center gap-2"
              >
                <span className="text-gray-900">Explore My Work</span>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
              </button>
              <button
                onClick={handleDownloadResume}
                className="bg-white text-gray-900 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex items-center gap-2"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <span className="text-gray-900">Download Resume</span>
              </button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 text-center">
                <div className="text-3xl font-bold">{data.stats.cgpa}</div>
                <div className="text-sm text-gray-200">CGPA</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 text-center">
                <div className="text-3xl font-bold">{data.stats.internships}</div>
                <div className="text-sm text-gray-200">Internships</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 text-center">
                <div className="text-3xl font-bold">{data.stats.technologies}</div>
                <div className="text-sm text-gray-200">Technologies</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            {/* Floating elements */}
            <div className="absolute -top-10 -right-10 w-20 h-20 bg-purple-400 rounded-full opacity-60 animate-pulse-slow"></div>
            <div className="absolute top-32 -right-6 w-12 h-12 bg-pink-400 rounded-full opacity-40 animate-float"></div>
            <div className="absolute -bottom-6 right-20 bg-white/20 backdrop-blur-sm rounded-lg p-3">
              <span className="text-white font-medium">Hi!</span>
            </div>
            
            <img
              src={data.profileImage}
              alt={`${data.name} - Professional Portrait`}
              className="rounded-full w-80 h-80 object-cover shadow-2xl border-4 border-white/20"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
