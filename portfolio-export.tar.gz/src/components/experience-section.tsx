import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface Experience {
  title: string;
  company: string;
  duration: string;
  status: string;
  highlight: string;
  projectTitle: string;
  type: string;
  responsibilities: string[];
  technologies: string[];
  icon: string;
  color: string;
}

interface ExperienceSectionProps {
  experiences: Experience[];
}

export default function ExperienceSection({ experiences }: ExperienceSectionProps) {
  const getColorClasses = (color: string) => {
    const colorMap = {
      purple: {
        bg: "from-purple-50 to-blue-50",
        icon: "bg-purple-600",
        badge: "bg-purple-100 text-purple-800",
        dot: "bg-purple-600"
      },
      blue: {
        bg: "from-blue-50 to-green-50",
        icon: "bg-blue-500",
        badge: "bg-blue-100 text-blue-800",
        dot: "bg-blue-500"
      },
      green: {
        bg: "from-green-50 to-teal-50",
        icon: "bg-green-500",
        badge: "bg-green-100 text-green-800",
        dot: "bg-green-500"
      }
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.purple;
  };

  const getIconElement = (iconName: string) => {
    const icons = {
      "chart-line": "📈",
      "python": "🐍",
      "globe": "🌐"
    };
    return icons[iconName as keyof typeof icons] || "💼";
  };

  const scrollToProjects = () => {
    document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="experience" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Professional <span className="text-purple-600">Experience</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Building expertise through hands-on internships and specialized training programs
          </p>
        </div>

        <div className="space-y-12">
          {experiences.map((exp, index) => {
            const colors = getColorClasses(exp.color);
            return (
              <div key={index} className="grid lg:grid-cols-12 gap-8 items-start">
                <div className="lg:col-span-3">
                  <div className={`bg-gradient-to-br ${colors.bg} rounded-2xl p-6 text-center sticky top-24`}>
                    <div className={`w-16 h-16 ${colors.icon} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                      <span className="text-white text-2xl">{getIconElement(exp.icon)}</span>
                    </div>
                    <h4 className="font-bold text-gray-900 mb-2">{exp.title}</h4>
                    <p className={`text-${exp.color}-600 font-semibold mb-2`}>{exp.company}</p>
                    <div className="text-sm text-gray-600 mb-4">{exp.duration}</div>
                    <Badge className={colors.badge}>
                      {exp.status}
                    </Badge>
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <div className="flex items-start gap-2">
                        <span className="text-yellow-500 mt-1">💡</span>
                        <div className="text-left">
                          <p className="font-medium text-gray-900 text-sm">Highlight</p>
                          <p className="text-xs text-gray-600">{exp.highlight}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="lg:col-span-9">
                  <Card className="shadow-lg border border-gray-100">
                    <CardContent className="p-8">
                      <h3 className="text-2xl font-bold text-gray-900 mb-4">{exp.projectTitle}</h3>
                      <Badge className={colors.badge} variant="secondary">
                        {exp.type}
                      </Badge>
                      
                      <div className="mb-6 mt-6">
                        <h4 className="font-semibold text-gray-900 mb-3">Key Responsibilities:</h4>
                        <ul className="space-y-2">
                          {exp.responsibilities.map((resp, respIndex) => (
                            <li key={respIndex} className="flex items-start gap-3">
                              <div className={`w-2 h-2 ${colors.dot} rounded-full mt-2 flex-shrink-0`}></div>
                              <span className="text-gray-700">{resp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="mb-6">
                        <h4 className="font-semibold text-gray-900 mb-3">Technologies Used:</h4>
                        <div className="flex flex-wrap gap-2">
                          {exp.technologies.map((tech, techIndex) => (
                            <Badge key={techIndex} variant="outline" className="text-xs">
                              {tech}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            );
          })}
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Ready for New Challenges</h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              I'm actively seeking opportunities to apply my skills and continue growing in data analysis and software development roles.
            </p>
            <Button onClick={scrollToProjects} variant="gradient" size="lg">
              <span>View My Projects</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
