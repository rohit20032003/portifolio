import { type Portfolio, type InsertPortfolio, type Contact, type InsertContact, type PortfolioData } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getPortfolio(userId: string): Promise<Portfolio | undefined>;
  createOrUpdatePortfolio(portfolio: InsertPortfolio): Promise<Portfolio>;
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
}

export class MemStorage implements IStorage {
  private portfolios: Map<string, Portfolio>;
  private contacts: Map<string, Contact>;

  constructor() {
    this.portfolios = new Map();
    this.contacts = new Map();
    
    // Initialize with default portfolio data
    this.initializeDefaultPortfolio();
  }

  private initializeDefaultPortfolio() {
    const defaultData: PortfolioData = {
      user: {
        name: "Rohit Kumar",
        fullName: "Madagala Rohit Kumar",
        tagline: "Driven by curiosity, powered by code — exploring innovative solutions through data and development.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800",
        email: "rohit.madagala@email.com",
        phone: "+91 XXXXX XXXXX",
        location: "Visakhapatnam, Andhra Pradesh",
        about: {
          subtitle: "A passionate engineering student dedicated to continuous learning and innovation"
        },
        mission: "I aim to build a career in a growing organization where I can showcase my abilities, take on challenges, contribute to its goals, and grow through continuous learning and dedication.",
        contactIntro: "I'm currently seeking opportunities in data analysis, software development and related fields. Whether you have a project in mind, want to discuss collaboration, or just want to connect, feel free to reach out!",
        stats: {
          cgpa: "9.33",
          internships: "3+",
          technologies: "5+"
        }
      },
      values: [
        { title: "Excellence", subtitle: "In Every Project", letter: "E" },
        { title: "Innovation", subtitle: "Through Technology", letter: "I" },
        { title: "Growth", subtitle: "Continuous Learning", letter: "G" },
        { title: "Impact", subtitle: "Meaningful Solutions", letter: "I" }
      ],
      education: [
        {
          degree: "B.Tech in Electronics & Communication Engineering",
          institution: "Raghu Institute of Technology",
          period: "2022 - 2026",
          cgpa: "CGPA: 9.33 (up to 3rd)"
        },
        {
          degree: "Intermediate (12th)",
          institution: "Sri Chaitanya Junior College",
          period: "2020 - 2022",
          percentage: "95.3%"
        },
        {
          degree: "SSC (10th)",
          institution: "Sri Chaitanya EM School",
          period: "2018 - 2020",
          percentage: "96.6%"
        }
      ],
      skills: {
        programmingLanguages: ["Python", "C", "C++", "Java"],
        dataAnalysisLibraries: ["Pandas", "NumPy", "Matplotlib", "Seaborn"],
        databaseTools: ["DBMS", "MySQL", "Git", "API Integration"],
        specializations: ["Data Visualization", "Graph-Based Testing", "Data Processing"],
        proficiencyLevels: [
          { name: "Python", category: "Programming", level: 90, color: "from-blue-400 to-purple-500" },
          { name: "Data Analysis", category: "Analytics", level: 85, color: "from-purple-400 to-pink-400" },
          { name: "C/C++", category: "Programming", level: 80, color: "from-green-400 to-blue-400" },
          { name: "MySQL", category: "Database", level: 78, color: "from-orange-400 to-red-400" },
          { name: "Java", category: "Programming", level: 70, color: "from-indigo-400 to-purple-400" },
          { name: "Git", category: "Tools", level: 85, color: "from-teal-400 to-blue-400" }
        ]
      },
      experiences: [
        {
          title: "Data Analysis Intern",
          company: "APSSDC",
          duration: "2 Months",
          status: "Completed",
          highlight: "Led full project ownership from data processing to reporting",
          projectTitle: "Outlet Performance & Item Analysis (Blinkit)",
          type: "Internship",
          responsibilities: [
            "Analyzed sales trends and outlet performance using Python libraries",
            "Created comprehensive data visualizations with Matplotlib and Seaborn",
            "Processed large datasets to extract meaningful business insights",
            "Delivered detailed insight reports on item visibility and performance metrics"
          ],
          technologies: ["Python", "Pandas", "NumPy", "Matplotlib", "Seaborn"],
          icon: "chart-line",
          color: "purple"
        },
        {
          title: "Python Developer Intern",
          company: "Infosys Springboard",
          duration: "2 Months",
          status: "Certified",
          highlight: "Successfully earned Infosys certification",
          projectTitle: "Python Programming Fundamentals",
          type: "Certification Program",
          responsibilities: [
            "Completed comprehensive Python programming certification",
            "Mastered core programming concepts and data structures",
            "Developed practical applications using Python",
            "Earned industry-recognized certification"
          ],
          technologies: ["Python", "Data Structures", "Algorithms", "OOP"],
          icon: "python",
          color: "blue"
        },
        {
          title: "Python Full Stack Intern",
          company: "Eduskills",
          duration: "8 Weeks",
          status: "Completed",
          highlight: "Comprehensive full stack training program",
          projectTitle: "Full Stack Web Development",
          type: "Intensive Training",
          responsibilities: [
            "Learned full stack development with Python backend",
            "Built responsive web applications",
            "Integrated frontend and backend technologies",
            "Gained hands-on experience with modern development tools"
          ],
          technologies: ["Python", "Web Development", "Frontend", "Backend"],
          icon: "globe",
          color: "green"
        }
      ],
      featuredProject: {
        title: "Outlet Performance & Item Analysis",
        category: "Blinkit Data Analytics Project",
        description: "Comprehensive analysis of outlet performance metrics and item visibility trends using Python data libraries. This project involved processing large datasets to extract meaningful business insights and create compelling visualizations for stakeholder reporting.",
        technologies: ["Python", "Pandas", "NumPy", "Matplotlib", "Seaborn", "Data Analysis"],
        achievements: [
          { value: "10K+", label: "Data Points Analyzed", icon: "chart-line" },
          { value: "50+", label: "Outlets Covered", icon: "store" },
          { value: "15+", label: "Key Insights", icon: "lightbulb" },
          { value: "25+", label: "Visualizations Created", icon: "chart-pie" }
        ],
        features: [
          { name: "Sales Trend Analysis", desc: "Identified seasonal patterns and growth opportunities" },
          { name: "Data Processing", desc: "Cleaned and structured raw business data efficiently" },
          { name: "Performance Metrics", desc: "Developed KPIs for outlet performance evaluation" },
          { name: "Interactive Visualizations", desc: "Created compelling charts and graphs for stakeholders" }
        ]
      },
      otherProjects: [
        {
          title: "Python Programming Portfolio",
          description: "Collection of Python projects demonstrating programming fundamentals and data structures.",
          status: "Ongoing",
          technologies: ["Python", "Data Structures", "Algorithms"],
          type: "Academic"
        },
        {
          title: "Database Management System",
          description: "University project involving database design and query optimization.",
          status: "Completed",
          technologies: ["MySQL", "Database Design", "SQL"],
          type: "Academic"
        },
        {
          title: "Full Stack Web Application",
          description: "Learning project from Eduskills training program.",
          status: "In Progress",
          technologies: ["Python", "Web Development", "Frontend"],
          type: "Training"
        }
      ]
    };

    const defaultPortfolio: Portfolio = {
      id: "default",
      userId: "default-user",
      data: defaultData
    };

    this.portfolios.set("default-user", defaultPortfolio);
  }

  async getPortfolio(userId: string): Promise<Portfolio | undefined> {
    return this.portfolios.get(userId);
  }

  async createOrUpdatePortfolio(insertPortfolio: InsertPortfolio): Promise<Portfolio> {
    const existing = this.portfolios.get(insertPortfolio.userId);
    const portfolio: Portfolio = {
      id: existing?.id || randomUUID(),
      ...insertPortfolio,
    };
    this.portfolios.set(insertPortfolio.userId, portfolio);
    return portfolio;
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = {
      ...insertContact,
      id,
      createdAt: new Date().toISOString(),
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }
}

export const storage = new MemStorage();
