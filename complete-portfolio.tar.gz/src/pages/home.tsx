import { useQuery } from "@tanstack/react-query";
import { type Portfolio } from "@shared/schema";
import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import SkillsSection from "@/components/skills-section";
import ExperienceSection from "@/components/experience-section";
import ProjectsSection from "@/components/projects-section";
import ContactSection from "@/components/contact-section";

export default function Home() {
  const { data: portfolio, isLoading } = useQuery<Portfolio>({
    queryKey: ["/api/portfolio/default-user"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!portfolio) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Portfolio Not Found</h1>
          <p className="text-gray-600">Unable to load portfolio data.</p>
        </div>
      </div>
    );
  }

  const portfolioData = portfolio.data as any;

  return (
    <div className="bg-gray-50">
      <Navigation userName={portfolioData.user.name} />
      <HeroSection data={portfolioData.user} />
      <AboutSection 
        user={portfolioData.user} 
        values={portfolioData.values} 
        education={portfolioData.education} 
      />
      <SkillsSection skills={portfolioData.skills} />
      <ExperienceSection experiences={portfolioData.experiences} />
      <ProjectsSection 
        featuredProject={portfolioData.featuredProject} 
        otherProjects={portfolioData.otherProjects} 
      />
      <ContactSection user={portfolioData.user} />
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-400">
              © 2024 <span className="text-purple-400">{portfolioData.user.name}</span>. All rights reserved.
            </p>
            <p className="text-gray-500 text-sm mt-2">
              Built with passion for data and technology
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
