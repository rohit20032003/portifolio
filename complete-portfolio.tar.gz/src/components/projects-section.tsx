import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface FeaturedProject {
  title: string;
  category: string;
  description: string;
  technologies: string[];
  achievements: {
    value: string;
    label: string;
    icon: string;
  }[];
  features: {
    name: string;
    desc: string;
  }[];
}

interface OtherProject {
  title: string;
  description: string;
  status: string;
  technologies: string[];
  type: string;
}

interface ProjectsSectionProps {
  featuredProject: FeaturedProject;
  otherProjects: OtherProject[];
}

export default function ProjectsSection({ featuredProject, otherProjects }: ProjectsSectionProps) {
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'ongoing':
        return 'bg-purple-100 text-purple-800';
      case 'in progress':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getAchievementIcon = (iconName: string) => {
    const icons = {
      "chart-line": "📈",
      "store": "🏪",
      "lightbulb": "💡",
      "chart-pie": "📊"
    };
    return icons[iconName as keyof typeof icons] || "📊";
  };

  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="projects" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Featured <span className="text-purple-600">Projects</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Showcasing real-world applications of data analysis and programming skills
          </p>
        </div>

        {/* Featured Project */}
        <Card className="shadow-xl border border-gray-100 mb-16">
          <CardContent className="p-8">
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-400 rounded-xl flex items-center justify-center">
                    <span className="text-white text-xl">📊</span>
                  </div>
                  <div>
                    <div className="text-sm text-purple-600 font-medium">FEATURED PROJECT</div>
                    <h3 className="text-2xl font-bold text-gray-900">{featuredProject.title}</h3>
                  </div>
                </div>
                
                <Badge className="bg-blue-100 text-blue-800">
                  {featuredProject.category}
                </Badge>
                
                <p className="text-gray-600 leading-relaxed">
                  {featuredProject.description}
                </p>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Technologies Used:</h4>
                    <div className="flex flex-wrap gap-2">
                      {featuredProject.technologies.map((tech, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <Button variant="gradient">
                    <span>👁️</span>
                    <span>View Details</span>
                  </Button>
                  <Button variant="outline">
                    <span>📂</span>
                    <span>Source Code</span>
                  </Button>
                </div>
              </div>
              
              <div className="space-y-6">
                <h4 className="text-xl font-bold text-gray-900">Key Features & Achievements</h4>
                <div className="grid grid-cols-2 gap-6">
                  {featuredProject.achievements.map((achievement, index) => (
                    <div key={index} className="text-center p-4 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
                      <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <span className="text-white text-sm">{getAchievementIcon(achievement.icon)}</span>
                      </div>
                      <div className="text-2xl font-bold text-gray-900">{achievement.value}</div>
                      <div className="text-sm text-gray-600">{achievement.label}</div>
                    </div>
                  ))}
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-3">
                    {featuredProject.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full"></div>
                        <span className="text-gray-700 font-medium">{feature.name}</span>
                        <span className="text-sm text-gray-500">{feature.desc}</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-green-500">✅</span>
                    <span className="font-semibold text-green-800">Project Completed Successfully</span>
                  </div>
                  <p className="text-sm text-green-700">Full ownership from data processing to insight reporting - 2 Months</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Other Projects - 3 column grid */}
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-12">Other Projects</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {otherProjects.map((project, index) => (
              <Card key={index} className="shadow-lg border border-gray-100 card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-bold text-gray-900">{project.title}</h4>
                    <Badge className={getStatusColor(project.status)}>
                      {project.status}
                    </Badge>
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-4">
                    {project.description}
                  </p>
                  
                  <div className="space-y-3 mb-4">
                    <div className="flex flex-wrap gap-1">
                      {project.technologies.map((tech, techIndex) => (
                        <Badge key={techIndex} variant="secondary" className="text-xs">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">{project.type}</span>
                    <Button variant="ghost" size="sm">
                      <span>🔗</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Collaboration CTA */}
        <div className="bg-gradient-to-r from-purple-100 to-blue-100 rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Interested in Collaboration?</h3>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
            I'm always excited to work on new data analysis projects and explore innovative solutions. 
            Let's connect and discuss how we can work together!
          </p>
          <Button onClick={scrollToContact} variant="gradient" size="lg">
            Get In Touch
          </Button>
        </div>
      </div>
    </section>
  );
}
